import { Router } from "express";
import { db } from "@workspace/db";
import { ordersTable, orderItemsTable, cartItemsTable, productsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import {
  CreateOrderBody,
  GetOrderParams,
} from "@workspace/api-zod";

const router = Router();

async function getOrderWithItems(orderId: number) {
  const order = await db.select().from(ordersTable).where(eq(ordersTable.id, orderId)).limit(1);
  if (!order.length) return null;

  const items = await db.select().from(orderItemsTable).where(eq(orderItemsTable.orderId, orderId));

  return {
    id: order[0].id,
    customerName: order[0].customerName,
    customerEmail: order[0].customerEmail,
    customerPhone: order[0].customerPhone,
    address: order[0].address,
    city: order[0].city,
    governorate: order[0].governorate,
    total: Number(order[0].total),
    status: order[0].status,
    items: items.map((i) => ({
      id: i.id,
      productId: i.productId,
      productName: i.productName,
      quantity: i.quantity,
      price: Number(i.price),
      size: i.size ?? null,
      color: i.color ?? null,
    })),
    createdAt: order[0].createdAt.toISOString(),
  };
}

router.get("/orders", async (req, res) => {
  try {
    const orders = await db.select().from(ordersTable).orderBy(desc(ordersTable.createdAt));
    const result = await Promise.all(orders.map((o) => getOrderWithItems(o.id)));
    res.json(result.filter(Boolean));
  } catch (err) {
    req.log.error({ err }, "Failed to list orders");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/orders/:id", async (req, res) => {
  try {
    const { id } = GetOrderParams.parse({ id: Number(req.params.id) });
    const order = await getOrderWithItems(id);
    if (!order) return res.status(404).json({ error: "Order not found" });
    res.json(order);
  } catch (err) {
    req.log.error({ err }, "Failed to get order");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/orders", async (req, res) => {
  try {
    const data = CreateOrderBody.parse(req.body);

    // Get cart items
    const cartItems = await db.select().from(cartItemsTable).where(eq(cartItemsTable.sessionId, data.sessionId));
    if (!cartItems.length) return res.status(400).json({ error: "Cart is empty" });

    // Enrich with product info and compute total
    const enriched = await Promise.all(
      cartItems.map(async (item) => {
        const product = await db.select().from(productsTable).where(eq(productsTable.id, item.productId)).limit(1);
        const p = product[0];
        return { item, product: p };
      })
    );

    const total = enriched.reduce((sum, { item, product }) => sum + Number(product?.price ?? 0) * item.quantity, 0);

    const [order] = await db
      .insert(ordersTable)
      .values({
        customerName: data.customerName,
        customerEmail: data.customerEmail,
        customerPhone: data.customerPhone,
        address: data.address,
        city: data.city,
        governorate: data.governorate,
        total: String(total),
        status: "pending",
        notes: data.notes,
      })
      .returning();

    // Insert order items
    await Promise.all(
      enriched.map(({ item, product }) =>
        db.insert(orderItemsTable).values({
          orderId: order.id,
          productId: item.productId,
          productName: product?.name ?? "Unknown",
          quantity: item.quantity,
          price: String(Number(product?.price ?? 0)),
          size: item.size,
          color: item.color,
        })
      )
    );

    // Clear cart
    await db.delete(cartItemsTable).where(eq(cartItemsTable.sessionId, data.sessionId));

    const result = await getOrderWithItems(order.id);
    res.status(201).json(result);
  } catch (err) {
    req.log.error({ err }, "Failed to create order");
    res.status(400).json({ error: "Invalid request" });
  }
});

export default router;
