import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Plus, Trash2, Package, ShoppingBag, X, ChevronDown, Eye
} from "lucide-react";
import {
  useListProducts,
  useListCategories,
  useListOrders,
  useCreateProduct,
  useDeleteProduct,
  useUpdateProduct,
  getListProductsQueryKey,
  getGetStoreSummaryQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

const ADMIN_PIN = "noka2024";

const SIZES_OPTIONS = [
  "XS", "S", "M", "L", "XL", "XXL",
  "مقاس 1 (45-70 كيلو)", "مقاس 2 (حتى 85 كيلو)"
];

const STATUS_COLORS: Record<string, string> = {
  pending: "bg-amber-100 text-amber-700",
  confirmed: "bg-blue-100 text-blue-700",
  shipped: "bg-purple-100 text-purple-700",
  delivered: "bg-green-100 text-green-700",
  cancelled: "bg-red-100 text-red-700",
};

interface ProductFormData {
  name: string;
  description: string;
  price: string;
  imageUrl: string;
  categoryId: string;
  sizes: string[];
  colors: string;
  inStock: boolean;
  isFeatured: boolean;
  isNew: boolean;
}

const EMPTY_FORM: ProductFormData = {
  name: "",
  description: "",
  price: "",
  imageUrl: "",
  categoryId: "",
  sizes: [],
  colors: "",
  inStock: true,
  isFeatured: false,
  isNew: false,
};

export default function Admin() {
  const [authed, setAuthed] = useState(false);
  const [pin, setPin] = useState("");
  const [pinError, setPinError] = useState(false);
  const [tab, setTab] = useState<"products" | "orders">("products");
  const [showAddForm, setShowAddForm] = useState(false);
  const [form, setForm] = useState<ProductFormData>(EMPTY_FORM);
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);
  const [expandedOrder, setExpandedOrder] = useState<number | null>(null);

  const queryClient = useQueryClient();
  const { data: products = [], isLoading: loadingProducts } = useListProducts();
  const { data: categories = [] } = useListCategories();
  const { data: orders = [], isLoading: loadingOrders } = useListOrders();
  const createProduct = useCreateProduct();
  const deleteProduct = useDeleteProduct();
  const updateProduct = useUpdateProduct();

  function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    if (pin === ADMIN_PIN) {
      setAuthed(true);
      setPinError(false);
    } else {
      setPinError(true);
    }
  }

  function invalidateProducts() {
    queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetStoreSummaryQueryKey() });
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const colors = form.colors
      .split(",")
      .map((c) => c.trim())
      .filter(Boolean);

    createProduct.mutate(
      {
        data: {
          name: form.name,
          description: form.description,
          price: Number(form.price) / 50,
          imageUrl: form.imageUrl || undefined,
          categoryId: form.categoryId ? Number(form.categoryId) : undefined,
          sizes: form.sizes,
          colors,
          inStock: form.inStock,
          isFeatured: form.isFeatured,
          isNew: form.isNew,
        },
      },
      {
        onSuccess: () => {
          invalidateProducts();
          setShowAddForm(false);
          setForm(EMPTY_FORM);
        },
      }
    );
  }

  function handleDelete(id: number) {
    deleteProduct.mutate(
      { id },
      {
        onSuccess: () => {
          invalidateProducts();
          setDeleteConfirm(null);
        },
      }
    );
  }

  function toggleStock(id: number, current: boolean) {
    updateProduct.mutate(
      { id, data: { inStock: !current } },
      { onSuccess: invalidateProducts }
    );
  }

  function toggleSize(s: string) {
    setForm((prev) => ({
      ...prev,
      sizes: prev.sizes.includes(s)
        ? prev.sizes.filter((x) => x !== s)
        : [...prev.sizes, s],
    }));
  }

  if (!authed) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center px-4 pt-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-card border border-border rounded-2xl p-8 w-full max-w-sm shadow-lg"
        >
          <h1 className="text-3xl font-serif font-bold text-foreground mb-1">Admin Panel</h1>
          <p className="text-sm text-muted-foreground mb-6">NŌKA Store Management</p>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1.5">PIN</label>
              <input
                type="password"
                value={pin}
                onChange={(e) => { setPin(e.target.value); setPinError(false); }}
                placeholder="Enter admin PIN"
                className={`w-full border rounded-lg px-4 py-3 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-primary/30 ${pinError ? "border-destructive" : "border-border"}`}
              />
              {pinError && <p className="text-xs text-destructive mt-1">Incorrect PIN</p>}
            </div>
            <button
              type="submit"
              className="w-full bg-primary text-primary-foreground py-3 rounded-full font-semibold text-sm tracking-wide"
            >
              Login
            </button>
          </form>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pt-20 pb-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-serif font-bold text-foreground">Admin Panel</h1>
            <p className="text-sm text-muted-foreground mt-1">Manage your NŌKA store</p>
          </div>
          <button
            onClick={() => setAuthed(false)}
            className="text-xs text-muted-foreground hover:text-foreground transition-colors border border-border px-4 py-2 rounded-full"
          >
            Log out
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-8 border-b border-border">
          {(["products", "orders"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`flex items-center gap-2 px-5 py-3 text-sm font-medium capitalize transition-all border-b-2 -mb-px ${
                tab === t
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              {t === "products" ? <Package className="w-4 h-4" /> : <ShoppingBag className="w-4 h-4" />}
              {t}
              <span className="bg-muted text-muted-foreground text-xs px-2 py-0.5 rounded-full font-normal">
                {t === "products" ? products.length : orders.length}
              </span>
            </button>
          ))}
        </div>

        {/* Products tab */}
        {tab === "products" && (
          <div>
            <div className="flex justify-end mb-5">
              <button
                onClick={() => { setShowAddForm(true); setForm(EMPTY_FORM); }}
                className="flex items-center gap-2 bg-primary text-primary-foreground px-5 py-2.5 rounded-full text-sm font-semibold shadow-sm hover:shadow-md transition-shadow"
              >
                <Plus className="w-4 h-4" /> Add Product
              </button>
            </div>

            {/* Add Product Modal */}
            <AnimatePresence>
              {showAddForm && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="fixed inset-0 bg-foreground/40 backdrop-blur-sm z-50 flex items-start justify-center p-4 overflow-y-auto"
                  onClick={(e) => { if (e.target === e.currentTarget) setShowAddForm(false); }}
                >
                  <motion.div
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 20 }}
                    className="bg-background rounded-2xl border border-border w-full max-w-2xl my-8 shadow-2xl"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <div className="flex items-center justify-between px-6 py-4 border-b border-border">
                      <h2 className="text-lg font-semibold font-serif">Add New Product</h2>
                      <button onClick={() => setShowAddForm(false)} className="p-1.5 hover:bg-muted rounded-full">
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <form onSubmit={handleSubmit} className="p-6 space-y-5">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="sm:col-span-2">
                          <label className="block text-sm font-medium mb-1.5">Product Name *</label>
                          <input required value={form.name} onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))}
                            placeholder="e.g. Linen Shirt" className="w-full border border-border rounded-lg px-4 py-2.5 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-primary/30" />
                        </div>

                        <div className="sm:col-span-2">
                          <label className="block text-sm font-medium mb-1.5">Description *</label>
                          <textarea required rows={3} value={form.description} onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))}
                            placeholder="Describe the product..." className="w-full border border-border rounded-lg px-4 py-2.5 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-primary/30 resize-none" />
                        </div>

                        <div>
                          <label className="block text-sm font-medium mb-1.5">Price (EGP) *</label>
                          <input required type="number" min="0" value={form.price} onChange={(e) => setForm((p) => ({ ...p, price: e.target.value }))}
                            placeholder="200" className="w-full border border-border rounded-lg px-4 py-2.5 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-primary/30" />
                        </div>

                        <div>
                          <label className="block text-sm font-medium mb-1.5">Category</label>
                          <select value={form.categoryId} onChange={(e) => setForm((p) => ({ ...p, categoryId: e.target.value }))}
                            className="w-full border border-border rounded-lg px-4 py-2.5 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-primary/30">
                            <option value="">None</option>
                            {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                          </select>
                        </div>

                        <div className="sm:col-span-2">
                          <label className="block text-sm font-medium mb-1.5">Image URL</label>
                          <input type="url" value={form.imageUrl} onChange={(e) => setForm((p) => ({ ...p, imageUrl: e.target.value }))}
                            placeholder="https://..." className="w-full border border-border rounded-lg px-4 py-2.5 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-primary/30" />
                        </div>

                        <div className="sm:col-span-2">
                          <label className="block text-sm font-medium mb-2">Sizes</label>
                          <div className="flex flex-wrap gap-2">
                            {SIZES_OPTIONS.map((s) => (
                              <button key={s} type="button" onClick={() => toggleSize(s)}
                                className={`px-3 py-1.5 rounded-md text-xs font-medium border transition-all ${form.sizes.includes(s) ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground hover:border-primary/50"}`}>
                                {s}
                              </button>
                            ))}
                          </div>
                        </div>

                        <div className="sm:col-span-2">
                          <label className="block text-sm font-medium mb-1.5">Colors (comma-separated)</label>
                          <input value={form.colors} onChange={(e) => setForm((p) => ({ ...p, colors: e.target.value }))}
                            placeholder="بنى, بيبى بلو, ابيض, اسود..." className="w-full border border-border rounded-lg px-4 py-2.5 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-primary/30" />
                        </div>

                        <div className="sm:col-span-2 flex gap-6 flex-wrap">
                          {([
                            { key: "inStock", label: "In Stock" },
                            { key: "isFeatured", label: "Featured" },
                            { key: "isNew", label: "New Arrival" },
                          ] as const).map(({ key, label }) => (
                            <label key={key} className="flex items-center gap-2 cursor-pointer select-none">
                              <input type="checkbox" checked={form[key]} onChange={(e) => setForm((p) => ({ ...p, [key]: e.target.checked }))}
                                className="w-4 h-4 accent-primary" />
                              <span className="text-sm">{label}</span>
                            </label>
                          ))}
                        </div>
                      </div>

                      <div className="flex gap-3 pt-2 border-t border-border">
                        <button type="button" onClick={() => setShowAddForm(false)}
                          className="flex-1 border border-border text-muted-foreground py-2.5 rounded-full text-sm font-medium hover:bg-muted transition-colors">
                          Cancel
                        </button>
                        <button type="submit" disabled={createProduct.isPending}
                          className="flex-1 bg-primary text-primary-foreground py-2.5 rounded-full text-sm font-semibold disabled:opacity-50">
                          {createProduct.isPending ? "Adding..." : "Add Product"}
                        </button>
                      </div>
                    </form>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Products list */}
            {loadingProducts ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => <div key={i} className="animate-pulse h-20 bg-muted rounded-xl" />)}
              </div>
            ) : (
              <div className="space-y-3">
                {products.map((product) => (
                  <motion.div
                    key={product.id}
                    layout
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex items-center gap-4 p-4 bg-card border border-border rounded-xl"
                  >
                    {/* Image */}
                    <div className="w-14 h-16 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                      {product.imageUrl ? (
                        <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <span className="text-xs font-serif text-muted-foreground/30">N</span>
                        </div>
                      )}
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground text-sm truncate">{product.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {product.categoryName || "No category"} &bull; {(product.price * 50).toLocaleString("en-EG")} EGP
                      </p>
                      {product.colors.length > 0 && (
                        <p className="text-xs text-muted-foreground mt-0.5">{product.colors.length} color{product.colors.length !== 1 ? "s" : ""}</p>
                      )}
                    </div>

                    {/* Status toggle */}
                    <button
                      onClick={() => toggleStock(product.id, product.inStock)}
                      className={`text-xs px-3 py-1 rounded-full font-medium flex-shrink-0 transition-colors ${
                        product.inStock ? "bg-green-100 text-green-700 hover:bg-green-200" : "bg-muted text-muted-foreground hover:bg-red-100 hover:text-red-700"
                      }`}
                    >
                      {product.inStock ? "In Stock" : "Out of Stock"}
                    </button>

                    {/* Delete */}
                    {deleteConfirm === product.id ? (
                      <div className="flex items-center gap-2 flex-shrink-0">
                        <button
                          onClick={() => handleDelete(product.id)}
                          className="text-xs px-3 py-1.5 bg-destructive text-destructive-foreground rounded-full font-medium"
                        >
                          Confirm
                        </button>
                        <button onClick={() => setDeleteConfirm(null)} className="text-xs text-muted-foreground hover:text-foreground">
                          Cancel
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setDeleteConfirm(product.id)}
                        className="p-2 text-muted-foreground hover:text-destructive transition-colors flex-shrink-0 rounded-lg hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Orders tab */}
        {tab === "orders" && (
          <div>
            {loadingOrders ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => <div key={i} className="animate-pulse h-20 bg-muted rounded-xl" />)}
              </div>
            ) : orders.length === 0 ? (
              <div className="text-center py-20">
                <ShoppingBag className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                <p className="text-muted-foreground">No orders yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {orders.map((order) => (
                  <motion.div
                    key={order.id}
                    layout
                    className="bg-card border border-border rounded-xl overflow-hidden"
                  >
                    <button
                      className="w-full flex items-center gap-4 p-4 text-left"
                      onClick={() => setExpandedOrder(expandedOrder === order.id ? null : order.id)}
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-0.5">
                          <p className="font-medium text-foreground text-sm">Order #{order.id}</p>
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${STATUS_COLORS[order.status] ?? "bg-muted text-muted-foreground"}`}>
                            {order.status}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {order.customerName} &bull; {order.customerPhone} &bull; {order.governorate}
                        </p>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <p className="font-bold text-primary text-sm">{(order.total * 50).toLocaleString("en-EG")} EGP</p>
                        <p className="text-xs text-muted-foreground">{new Date(order.createdAt).toLocaleDateString("en-EG")}</p>
                      </div>
                      <ChevronDown className={`w-4 h-4 text-muted-foreground flex-shrink-0 transition-transform ${expandedOrder === order.id ? "rotate-180" : ""}`} />
                    </button>

                    <AnimatePresence>
                      {expandedOrder === order.id && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="overflow-hidden"
                        >
                          <div className="px-4 pb-4 border-t border-border pt-3 space-y-3">
                            <div className="text-sm text-muted-foreground">
                              <p><span className="font-medium text-foreground">Address:</span> {order.address}, {order.city}, {order.governorate}</p>
                              <p><span className="font-medium text-foreground">Email:</span> {order.customerEmail}</p>
                            </div>
                            <div className="space-y-2">
                              {order.items.map((item) => (
                                <div key={item.id} className="flex justify-between text-sm">
                                  <span className="text-foreground">{item.productName} {item.size ? `(${item.size})` : ""} &times; {item.quantity}</span>
                                  <span className="font-medium">{(item.price * item.quantity * 50).toLocaleString("en-EG")} EGP</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
